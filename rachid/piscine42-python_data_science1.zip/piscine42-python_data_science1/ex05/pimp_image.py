import matplotlib.pyplot as plt
import numpy as np


def check_image(pixels: np.ndarray) -> None:
    """Exit with a clear message if pixels is not an RGB image array."""
    if not isinstance(pixels, np.ndarray):
        print("Error: the image must be a numpy array")
        raise SystemExit(1)
    if pixels.ndim != 3 or pixels.shape[2] != 3:
        print("Error: the image must have shape (height, width, 3)")
        raise SystemExit(1)


def show(pixels: np.ndarray, title: str) -> None:
    """Display an image without axes."""
    plt.imshow(pixels)
    plt.title(title)
    plt.axis("off")
    plt.show()


def ft_invert(array: np.ndarray) -> np.ndarray:
    """Invert the colors of the image received."""
    check_image(array)
    inverted = 255 - array
    show(inverted, "Inverted")
    return inverted


def ft_red(array: np.ndarray) -> np.ndarray:
    """Keep only the red channel of the image received."""
    check_image(array)
    keep_red = np.array([1, 0, 0], dtype=np.uint8)
    red = array * keep_red
    show(red, "Red")
    return red


def ft_green(array: np.ndarray) -> np.ndarray:
    """Keep only the green channel of the image received."""
    check_image(array)
    green = array.copy()
    green[:, :, 0] = green[:, :, 0] - array[:, :, 0]
    green[:, :, 2] = green[:, :, 2] - array[:, :, 2]
    show(green, "Green")
    return green


def ft_blue(array: np.ndarray) -> np.ndarray:
    """Keep only the blue channel of the image received."""
    check_image(array)
    blue = np.zeros_like(array)
    blue[:, :, 2] = array[:, :, 2]
    show(blue, "Blue")
    return blue


def ft_grey(array: np.ndarray) -> np.ndarray:
    """Convert the image received to greyscale."""
    check_image(array)
    level = np.sum(array / 3, axis=2).astype(np.uint8)
    grey = np.stack([level, level, level], axis=2)
    show(grey, "Grey")
    return grey
