import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


def ft_load(path: str) -> np.ndarray:
    """Load an RGB image, print its data and display it."""
    try:
        if not isinstance(path, str):
            raise TypeError("path must be a string")
        with Image.open(path) as picture:
            if picture.mode != "RGB":
                raise ValueError("image must be coded in RGB")
            pixels = np.array(picture)
    except (OSError, TypeError, ValueError) as problem:
        print(f"Error: {problem}")
        raise SystemExit(1)

    print(f"The shape of image is: {pixels.shape}")
    print(pixels)
    plt.imshow(pixels)
    plt.title("Original")
    plt.axis("off")
    plt.show()
    return pixels
