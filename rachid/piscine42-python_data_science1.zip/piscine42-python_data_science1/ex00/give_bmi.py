import numpy as np


def check_numbers(values: list, name: str) -> None:
    """Raise if values is not a list of int or float."""
    if not isinstance(values, list):
        raise TypeError(f"{name} must be a list")
    for value in values:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{name} must contain only int or float")


def give_bmi(height: list[int | float],
             weight: list[int | float]) -> list[int | float]:
    """Calculate BMI for each height and weight."""
    check_numbers(height, "height")
    check_numbers(weight, "weight")
    if len(height) != len(weight):
        raise ValueError("height and weight must have the same size")
    heights = np.array(height, dtype=float)
    weights = np.array(weight, dtype=float)
    if np.any(heights <= 0) or np.any(weights <= 0):
        raise ValueError("numbers in lists must be greater than 0")
    return (weights / heights ** 2).tolist()


def apply_limit(bmi: list[int | float], limit: int) -> list[bool]:
    """Return which BMI values exceed the limit."""
    check_numbers(bmi, "bmi")
    if isinstance(limit, bool) or not isinstance(limit, int):
        raise TypeError("limit must be an int")
    return [bool(value > limit) for value in bmi]
