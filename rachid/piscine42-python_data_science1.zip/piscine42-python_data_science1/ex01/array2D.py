def slice_me(family: list, start: int, end: int) -> list:
    """Print the shape of a 2D list and return a sliced set of rows."""
    if not isinstance(family, list) or not family:
        raise TypeError("family must be a non-empty list")
    for row in family:
        if not isinstance(row, list) or not row:
            raise TypeError("family must be a 2D list of non-empty rows")
        if len(row) != len(family[0]):
            raise ValueError("all rows must have the same length")
        for value in row:
            if isinstance(value, bool) or not isinstance(value,
                                                         (int, float)):
                raise TypeError("family must contain only int or float")
    for name, bound in (("start", start), ("end", end)):
        if isinstance(bound, bool) or not isinstance(bound, int):
            raise TypeError(f"{name} must be an int")

    width = len(family[0])
    print(f"My shape is : {(len(family), width)}")
    sliced = family[start:end]
    print(f"My new shape is : {(len(sliced), width)}")
    return sliced
