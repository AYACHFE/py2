import matplotlib.pyplot as plt
import numpy as np

from load_image import ft_load


def transpose(pixels: np.ndarray) -> np.ndarray:
    """Transpose a 3D single-channel image by hand, without a library."""
    if pixels.ndim != 3:
        raise ValueError("image must have 3 dimensions")
    rows, cols = pixels.shape[:2]
    flipped = np.zeros((cols, rows), dtype=pixels.dtype)
    for row in range(rows):
        for col in range(cols):
            flipped[col][row] = pixels[row][col][0]
    return flipped


def main() -> None:
    """Load a square of the image, transpose it, print and display it."""
    try:
        pixels = ft_load("animal.jpeg")
        print(f"The shape of image is: {pixels.shape} or "
              f"{pixels.shape[:2]}")
        print(pixels)

        flipped = transpose(pixels)
        print(f"New shape after Transpose: {flipped.shape}")
        print(flipped)

        plt.imshow(flipped, cmap="gray")
        plt.xlabel("X (pixels)")
        plt.ylabel("Y (pixels)")
        plt.show()
    except ValueError as problem:
        print(f"Error: {problem}")
    except Exception as problem:
        print(f"Unexpected error: {problem}")


if __name__ == "__main__":
    main()
