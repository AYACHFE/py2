import numpy as np
from PIL import Image


def crop_square(pixels: np.ndarray, top: int = 100, left: int = 450,
                size: int = 400) -> np.ndarray:
    """Cut a square region of the image and keep a single channel."""
    height, width = pixels.shape[:2]
    if top + size > height or left + size > width:
        raise ValueError(
            f"square area does not fit in the image ({height}x{width})"
        )
    return pixels[top:top + size, left:left + size, 0:1]


def ft_load(path: str) -> np.ndarray:
    """Load an RGB image from disk and return a cropped square of it."""
    try:
        if not isinstance(path, str):
            raise TypeError("path must be a string")
        with Image.open(path) as picture:
            if picture.mode != "RGB":
                raise ValueError("image must be coded in RGB")
            pixels = np.array(picture)
        return crop_square(pixels)
    except (OSError, TypeError, ValueError) as problem:
        print(f"Error: {problem}")
        raise SystemExit(1)
